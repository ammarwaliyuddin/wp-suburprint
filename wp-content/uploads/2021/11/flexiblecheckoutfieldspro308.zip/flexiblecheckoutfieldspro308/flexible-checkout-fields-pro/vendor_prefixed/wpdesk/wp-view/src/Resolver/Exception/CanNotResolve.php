<?php

namespace FCFProVendor\WPDesk\View\Resolver\Exception;

class CanNotResolve extends \RuntimeException
{
}
